#include "CarMap.h"
#include "Map.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;


int main()
{
	CarMap c;
	
	// CarMap() 
	assert(c.fleetSize() == 0);

	// addCar() fleetSize()
	assert(c.addCar("Toyota") == true);
	assert(c.addCar("Toyota") == false);
	assert(c.fleetSize() == 1);

	// miles() drive()
	assert(c.miles("Toyota") == 0);
	assert(c.addCar("Tesla") == true);
	assert(c.drive("Tesla", 54) == true);
	assert(c.miles("Tesla") == 54);
	assert(c.drive("Tesla", 2) == true);
	assert(c.miles("Tesla") == 56);

	// print() COMMENT OUT
	// c.print();

	// SHOULD PRINT
		// Toyota 0
		// Tesla 56
	
}