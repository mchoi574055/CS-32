#include "Map.h"
#include <iostream>
#include <cassert>
using namespace std;

// To test a Map from string to double, leave the following line commented out;
// to test a Map from int to string, remove the "//".

// #define INT_TO_STRING

#ifdef INT_TO_STRING

const KeyType DUMMY_KEY = 9876543;
const ValueType DUMMY_VALUE = "Ouch";
const KeyType NO_SUCH_KEY = 42;
const KeyType KEY1 = 123456789;
const ValueType VALUE1 = "Wow!";

#else // assume string to double

const KeyType DUMMY_KEY = "hello";
const ValueType DUMMY_VALUE = -1234.5;
const KeyType NO_SUCH_KEY = "abc";
const KeyType KEY1 = "xyz";
const ValueType VALUE1 = 9876.5;

#endif // INT_TO_STRING

int main()
{
	Map m;

	// empty()
	assert(m.empty() == true);

	// insert() size() 
	assert(m.insert("Smallberg", 24) == true);
	assert(m.size() == 1);
	for (ValueType i = 0; i < 239; i++)
		m.insert("Smallberg", 55);
	assert(m.size() == 1);
	for (ValueType i = 0; i < 239; i++)
		m.insert("Nachenberg", 55);
	assert(m.size() == 2);
	for (ValueType i = 0; i < 238; i++)
	{
		KeyType s = "s";
		for (ValueType j = 0; j < i; j++)
			s += "s";
		m.insert("Nachenberg" + s, 55);
	}
	assert(m.size() == 240);

	// update() 3 arg get()
	assert(m.update("Smallberg", 21) == true);
	KeyType s = "FakeSmallberg";
	ValueType value = 212121;
	assert(m.get(0, s, value) == true);
	assert(s == "Smallberg");
	assert(value == 21);
	assert(m.update("FakeSmallberg", 21) == false);
	assert(m.get(241, s, value) == false);

	// insertOrUpdate() 2 arg get() erase() contains()
	ValueType value2 = 11;
	assert(m.insertOrUpdate("Nachenberg", value2) == true);
	assert(m.get("Nachenberg", value2) == true);
	assert(value2 == 11);
	assert(m.erase("Nachenberg") == true);
	assert(m.size() == 239);
	assert(m.contains("Nachenberg") == false);
	assert(m.insertOrUpdate("Nachenberg", value2) == true);
	assert(m.get(239, s, value) == true);
	assert(s == "Nachenberg");
	assert(value == value2);
	assert(m.contains("Nachenberg") == true);

	// swap()
	Map m2;
	for (ValueType i = 0; i < 70; i++)
	{
		KeyType s2 = "h";
		KeyType check = "Berg";
		for (ValueType j = 0; j < i; j++)
			s2 += "h";
		check += s2;
		assert(m2.insert(check, 20) == true);
	}

	m.swap(m2);
	assert(m2.size() == 240);
	assert(m.size() == 70);

	for (ValueType i = 0; i < 70; i++)
	{
		KeyType s2 = "h";
		KeyType check = "Berg";
		KeyType dum = "dump";
		for (ValueType j = 0; j < i; j++)
			s2 += "h";
		check += s2;
		assert(m.get(i, dum, value2) == true);
		assert(dum == check);
	}

	KeyType dum = "trash";
	assert(m2.get(0, dum, value) == true);
	assert(dum == "Smallberg");
	assert(value == 21);
	assert(m2.get(239, dum, value) == true);
	assert(dum == "Nachenberg");
	assert(value == 11);

	for (ValueType i = 1; i < 239; i++)
	{
		KeyType s2 = "s";
		KeyType check = "Nachenberg";
		KeyType dump = "dumppp";
		for (ValueType j = 1; j < i; j++)
			s2 += "s";
		check += s2;
		assert(m2.get(i, dump, value) == true);
		assert(dump == check);
	}

	// INT_TO_STRING OR REGULAR STRING TO DOUBLE

	Map r;
	assert(r.empty());
	ValueType vq = DUMMY_VALUE;
	assert(!r.get(NO_SUCH_KEY, vq) && vq == DUMMY_VALUE); // v unchanged by get failure
	r.insert(KEY1, VALUE1);
	assert(r.size() == 1);
	KeyType kq = DUMMY_KEY;
	assert(r.get(0, kq, vq) && kq == KEY1 && vq == VALUE1);
}

