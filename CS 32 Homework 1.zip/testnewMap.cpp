#include "newMap.h"
#include <cassert>
#include <iostream>

int main()
{
	Map m;
	Map bi(1000);
	// empty()
	assert(m.empty() == true);

	// insert() size() 
	assert(m.insert("Smallberg", 24) == true);
	assert(m.size() == 1);
	for (ValueType i = 0; i < 239; i++)
		m.insert("Smallberg", 55);
	assert(m.size() == 1);
	for (ValueType i = 0; i < 239; i++)
		m.insert("Nachenberg", 55);
	assert(m.size() == 2);
	for (ValueType i = 0; i < 238; i++)
	{
		KeyType s = "s";
		for (ValueType j = 0; j < i; j++)
			s += "s";
		m.insert("Nachenberg" + s, 55);
	}
	assert(m.size() == 240);
	assert(bi.size() == 0);


	// update() 3 arg get()
	assert(m.update("Smallberg", 21) == true);
	KeyType s = "FakeSmallberg";
	ValueType value = 212121;
	assert(m.get(0, s, value) == true);
	assert(s == "Smallberg");
	assert(value == 21);
	assert(m.update("FakeSmallberg", 21) == false);
	assert(m.get(241, s, value) == false);

	// insertOrUpdate() 2 arg get() erase() contains()
	ValueType value2 = 11;
	assert(m.insertOrUpdate("Nachenberg", value2) == true);
	assert(m.get("Nachenberg", value2) == true);
	assert(value2 == 11);
	assert(m.erase("Nachenberg") == true);
	assert(m.size() == 239);
	assert(m.contains("Nachenberg") == false);
	assert(m.insertOrUpdate("Nachenberg", value2) == true);
	assert(m.get(239, s, value) == true);
	assert(s == "Nachenberg");
	assert(value == value2);
	assert(m.contains("Nachenberg") == true);

	// swap()
	Map m2;
	for (ValueType i = 0; i < 70; i++)
	{
		KeyType s2 = "h";
		KeyType check = "Berg";
		for (ValueType j = 0; j < i; j++)
			s2 += "h";
		check += s2;
		assert(m2.insert(check, 20) == true);
	}

	m.swap(m2);
	assert(m2.size() == 240);
	assert(m.size() == 70);

	for (ValueType i = 0; i < 70; i++)
	{
		KeyType s2 = "h";
		KeyType check = "Berg";
		KeyType dum = "dump";
		for (ValueType j = 0; j < i; j++)
			s2 += "h";
		check += s2;
		assert(m.get(i, dum, value2) == true);
		assert(dum == check);
	}

	KeyType dum = "trash";
	assert(m2.get(0, dum, value) == true);
	assert(dum == "Smallberg");
	assert(value == 21);
	assert(m2.get(239, dum, value) == true);
	assert(dum == "Nachenberg");
	assert(value == 11);

	for (ValueType i = 1; i < 239; i++)
	{
		KeyType s2 = "s";
		KeyType check = "Nachenberg";
		KeyType dump = "dumppp";
		for (ValueType j = 1; j < i; j++)
			s2 += "s";
		check += s2;
		assert(m2.get(i, dump, value) == true);
		assert(dump == check);
	}

	Map a(1000);   // a can hold at most 1000 key/value pairs
	Map b(5);      // b can hold at most 5 key/value pairs
	Map c;         // c can hold at most DEFAULT_MAX_ITEMS key/value pairs
	KeyType k[6] = { "a", "b", "c", "d", "e", "f" };
	ValueType v = 2;

	// No failures inserting pairs with 5 distinct keys into b
	for (int n = 0; n < 5; n++)
		assert(b.insert(k[n], v));

	// Failure if we try to insert a pair with a sixth distinct key into b
	assert(!b.insert(k[5], v));

	// When two Maps' contents are swapped, their capacities are swapped
	// as well:
	a.swap(b);
	assert(!a.insert(k[5], v) && b.insert(k[5], v));


}