#include "Map.h"
#include <string>
#include <stack>
#include <cctype>

using namespace std;

int evaluate(string infix, const Map& values, string& postfix, int& result)
// Evaluates an integer arithmetic expression
//   If infix is a syntactically valid infix integer expression whose
//   only operands are single lower case letters (whether or not they
//   appear in the values map), then postfix is set to the postfix
//   form of the expression; otherwise postfix may or may not be
//   changed, result is unchanged, and the function returns 1.  If
//   infix is syntactically valid but contains at least one lower
//   case letter operand that does not appear in the values map, then
//   result is unchanged and the function returns 2.  If infix is
//   syntactically valid and all its lower case operand letters
//   appear in the values map, then if evaluating the expression
//   (using for each letter in the expression the value in the map
//   that corresponds to it) attempts to divide by zero, then result
//   is unchanged and the function returns 3; otherwise, result is
//   set to the value of the expression and the function returns 0.
{
	postfix = ""; 
	stack<char> operators;
	bool expectingoperand = true;
	bool expectingoperator = false;
	int expectingclosedparentheses = 0;
	bool expectingoperandinparentheses = false;
	bool precedencelowerorequal = false;

	if (infix == "")
		return 1;

	for (int i = 0; i < infix.size(); i++)
	{
		precedencelowerorequal = false;

		switch (infix[i])
		{
		default:
			if (!islower(infix[i]))
				return 1;

			if (expectingoperator == true)
				return 1;

			if (expectingoperandinparentheses == true)
				expectingoperandinparentheses = false;

			postfix += infix[i];
			expectingoperand = false;
			expectingoperator = true;
			break;

		case ' ': break;

		case '(':
			if (expectingoperator == true)
				return 1;
			operators.push('(');
			expectingclosedparentheses++;
			expectingoperandinparentheses = true;
			break;

		case ')':
			if ((expectingoperand == true) || (expectingoperandinparentheses == true))
				return 1;

			expectingoperandinparentheses = false;

			while (operators.top() != '(')
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.pop();
			expectingclosedparentheses--;
			break;

		case '+':
			precedencelowerorequal = true;
						if (expectingoperand == true)
				return 1;

			if ((!operators.empty()) && ((infix[i] == '*') || (infix[i] == '/')) && ((operators.top() == '*') || (operators.top() == '/')))
				precedencelowerorequal = true;

			while ((!operators.empty()) && (operators.top() != '(') && (precedencelowerorequal == true))
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.push(infix[i]);
			expectingoperand = true;
			expectingoperator = false;
			break;
		case '-':
			precedencelowerorequal = true;
			if (expectingoperand == true)
				return 1;

			if ((!operators.empty()) && ((infix[i] == '*') || (infix[i] == '/')) && ((operators.top() == '*') || (operators.top() == '/')))
				precedencelowerorequal = true;

			while ((!operators.empty()) && (operators.top() != '(') && (precedencelowerorequal == true))
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.push(infix[i]);
			expectingoperand = true;
			expectingoperator = false;
			break;
		case '*':
			if (expectingoperand == true)
				return 1;

			if ((!operators.empty()) && ((infix[i] == '*') || (infix[i] == '/')) && ((operators.top() == '*') || (operators.top() == '/')))
				precedencelowerorequal = true;

			while ((!operators.empty()) && (operators.top() != '(') && (precedencelowerorequal == true))
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.push(infix[i]);
			expectingoperand = true;
			expectingoperator = false;
			break;
		case '/':
			if (expectingoperand == true)
				return 1;

			if ((!operators.empty()) && ((infix[i] == '*') || (infix[i] == '/')) && ((operators.top() == '*') || (operators.top() == '/')))
				precedencelowerorequal = true;

			while ((!operators.empty()) && (operators.top() != '(') && (precedencelowerorequal == true))
			{
				postfix += operators.top();
				operators.pop();
			}
			operators.push(infix[i]);
			expectingoperand = true;
			expectingoperator = false;
			break;
		}
	}

	if ((expectingclosedparentheses != 0) || expectingoperand == true)
		return 1;

	while (!operators.empty())
	{
		postfix += operators.top();
		operators.pop();
	}

	stack<int> operands;
	int temp;
	


	for (int i = 0; i < postfix.size(); i++)
	{
		if (islower(postfix[i]))  
		{
			if (!values.get(postfix[i], temp))
			{
				return 2;
			}
			else
				operands.push(temp);
		}
		else
		{
			int operand2 = operands.top();
			operands.pop();
			int operand1 = operands.top();
			operands.pop();

			switch (postfix[i])
			{
			case '+':
				operands.push(operand1 + operand2);
				break;
			case '-':
				operands.push(operand1 - operand2);
				break;
			case '*':
				operands.push(operand1 * operand2);
				break;
			case '/':
				if (operand2 == 0)
					return 3;
				operands.push(operand1 / operand2);
				break;
			}
		}
	}
	result = operands.top();
	return 0;
}

int main()
{
}