#include <string>
#include <stack>

using namespace std;

class Coord
{
public:
	Coord(int rr, int cc) : m_r(rr), m_c(cc) {}
	int r() const { return m_r; }
	int c() const { return m_c; }
private:
	int m_r;
	int m_c;
};


bool pathExists(string maze[], int nRows, int nCols, int sr, int sc, int er, int ec)
// Return true if there is a path from (sr,sc) to (er,ec)
// through the maze; return false otherwise
{
	stack<Coord> coordStack;
	coordStack.push(Coord(sr, sc));
	maze[sr][sc] = '$';

	while (!coordStack.empty())
	{
		Coord temp = coordStack.top();
		coordStack.pop();

		if ((temp.r() == er) && (temp.c() == ec))
			return true;

		// EAST
		if ((temp.c() + 1 <= nCols - 1) && maze[temp.r()][temp.c() + 1] == '.')
		{
			coordStack.push(Coord(temp.r(), temp.c() + 1));
			maze[temp.r()][temp.c() + 1] = '$';
		}
		// SOUTH
		if ((temp.r() + 1 <= nRows - 1) && maze[temp.r() + 1][temp.c()] == '.')
		{
			coordStack.push(Coord(temp.r() + 1, temp.c()));
			maze[temp.r() + 1][temp.c()] = '$';
		}
		// WEST
		if ((temp.c() - 1 >= 0) && maze[temp.r()][temp.c() - 1] == '.')
		{
			coordStack.push(Coord(temp.r(), temp.c() - 1));
			maze[temp.r()][temp.c() - 1] = '$';
		}
		// NORTH
		if ((temp.r() - 1 >= 0) && maze[temp.r() - 1][temp.c()] == '.')
		{
			coordStack.push(Coord(temp.r() - 1, temp.c()));
			maze[temp.r() - 1][temp.c()] = '$';
		}
	}

	return false;
}

int main()
{
}
