class Event
{
	public:
		Event(string name_input);
		string name() const;
		bool isSport() const;
		virtual string need() const = 0;
		virtual ~Event();
		
	private:
		string event_name;
};

Event::Event(string name_input)
{
	event_name = name_input;
}

string Event::name() const
{
	return event_name;
}

bool Event::isSport() const
{
	return((need() == "hoops") || (need() == "ice"));
}

Event::~Event()
{
}
		

class BasketballGame : public Event
{
	public:
		BasketballGame(string name_input);
		string need() const;
		~BasketballGame();
};

BasketballGame::BasketballGame(string name_input)
	: Event(name_input)
{
}

BasketballGame::~BasketballGame()
{
	cout << "Destroying the " << name() << " basketball game" << endl;
}

string BasketballGame::need() const
{
	return "hoops";
}

class HockeyGame : public Event
{
	public:
		HockeyGame(string name_input);
		string need() const;
		~HockeyGame();
};

HockeyGame::HockeyGame(string name_input)
	: Event(name_input)
{
}

string HockeyGame::need() const
{
	return "ice";
}

HockeyGame::~HockeyGame()
{
	cout << "Destroying the " << name() << " hockey game" << endl;
}

class Concert : public Event
{
	public:
		Concert(string name_input, string concert_type_input);
		string need() const;
		~Concert();
	private:
		string concert_type;
};

Concert::Concert(string name_input, string concert_type_input)
	: Event(name_input)
{
	concert_type = concert_type_input;
}

string Concert::need() const
{
	return "a stage";
}

Concert::~Concert()
{
	cout << "Destroying the " << name() << " " << concert_type << " concert" << endl;
}
