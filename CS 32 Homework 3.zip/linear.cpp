bool anyFalse(const double a[], int n)
{
	if (n <= 0)
		return false;

	else
	{
		if (!somePredicate(a[0]))
			return true;

		return (anyFalse(a + 1, n - 1));
	}
}

int countTrue(const double a[], int n)
{
	if (n <= 0)
		return 0;

	else
	{
		int i = 0;
		if (somePredicate(a[0]))
			i = 1;
		return i + countTrue(a + 1, n - 1);
	}
}


int firstTrue(const double a[], int n)
{
	if (n <= 0)
		return -1;

	else
	{
		int pos = firstTrue(a, n - 1);

		if (pos == -1)
		{
			if (somePredicate(a[n - 1]))
				return n - 1;
			else
				return -1;
		}
		return pos;
	}
}


int positionOfSmallest(const double a[], int n)
{
	if (n <= 0)
		return -1;

	else
	{

		int pos = positionOfSmallest(a, n - 1);

		if (pos == -1)
		{
			pos++;
		}

		double potential_lowest = a[n - 1];

		if (potential_lowest < a[pos])
			return (n - 1);
		else
			return pos;

	}
}

bool contains(const double a1[], int n1, const double a2[], int n2)
{	

	if (n2 <= 0)
		return true;
	if (n1 <= 0)
		return false;


	if (a1[0] == a2[0])
	{
		return (contains(a1 + 1, n1 - 1, a2 + 1, n2 - 1));
	}

	return (contains(a1 + 1, n1 - 1, a2, n2));
}
