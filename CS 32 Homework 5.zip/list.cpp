
void listAll(string path, const Class* c)  // two-parameter overload
{
	string out = path + c->name();
	cout << out << endl;

	if (c->subclasses().empty())
	{
		return;
	}

	path = path + c->name() + "=>";

	for (int i = 0; i < c->subclasses().size(); i++)
	{
		listAll(path, c->subclasses()[i]); 
	}
}

