#include "History.h"
#include <iostream>
#include "globals.h"

using namespace std;

History::History(int nRows, int nCols)
{
	m_rows = nRows;
	m_cols = nCols;

	for (int r = 1; r <= m_rows; r++)
		for (int c = 1; c <= m_cols; c++)
			m_historydisplaygrid[r - 1][c - 1] = '.';

	for (int r = 1; r <= m_rows; r++)
		for (int c = 1; c <= m_cols; c++)
			m_gridpoisoned[r - 1][c - 1] = 0;
}

bool History::record(int r, int c)
{
	if ((r <= 0) || (r > m_rows) || (c <= 0) || (c > m_cols))
		return false;

	m_gridpoisoned[r - 1][c - 1]++;

			switch (m_gridpoisoned[r - 1][c - 1])
			{
				case 0: m_historydisplaygrid[r - 1][c - 1] = '.'; break;
				case 1: m_historydisplaygrid[r - 1][c - 1] = 'A'; break;
				case 2: m_historydisplaygrid[r - 1][c - 1] = 'B'; break;
				case 3: m_historydisplaygrid[r - 1][c - 1] = 'C'; break;
				case 4: m_historydisplaygrid[r - 1][c - 1] = 'D'; break;
				case 5: m_historydisplaygrid[r - 1][c - 1] = 'E'; break;
				case 6: m_historydisplaygrid[r - 1][c - 1] = 'F'; break;
				case 7: m_historydisplaygrid[r - 1][c - 1] = 'G'; break;
				case 8: m_historydisplaygrid[r - 1][c - 1] = 'H'; break;
				case 9: m_historydisplaygrid[r - 1][c - 1] = 'I'; break;
				case 10: m_historydisplaygrid[r - 1][c - 1] = 'J'; break;
				case 11: m_historydisplaygrid[r - 1][c - 1] = 'K'; break;
				case 12: m_historydisplaygrid[r - 1][c - 1] = 'L'; break;
				case 13: m_historydisplaygrid[r - 1][c - 1] = 'M'; break;
				case 14: m_historydisplaygrid[r - 1][c - 1] = 'N'; break;
				case 15: m_historydisplaygrid[r - 1][c - 1] = 'O'; break;
				case 16: m_historydisplaygrid[r - 1][c - 1] = 'P'; break;
				case 17: m_historydisplaygrid[r - 1][c - 1] = 'Q'; break;
				case 18: m_historydisplaygrid[r - 1][c - 1] = 'R'; break;
				case 19: m_historydisplaygrid[r - 1][c - 1] = 'S'; break;
				case 20: m_historydisplaygrid[r - 1][c - 1] = 'T'; break;
				case 21: m_historydisplaygrid[r - 1][c - 1] = 'U'; break;
				case 22: m_historydisplaygrid[r - 1][c - 1] = 'V'; break;
				case 23: m_historydisplaygrid[r - 1][c - 1] = 'W'; break;
				case 24: m_historydisplaygrid[r - 1][c - 1] = 'X'; break;
				case 25: m_historydisplaygrid[r - 1][c - 1] = 'Y'; break;
				case 26: m_historydisplaygrid[r - 1][c - 1] = 'Z'; break;
				default: m_historydisplaygrid[r - 1][c - 1] = 'Z'; break;
			}

	return true;
}

void History::display() const
{
	clearScreen();

	for (int r = 1; r <= m_rows; r++)
	{
		for (int c = 1; c <= m_cols; c++)
		{
			cout << m_historydisplaygrid[r - 1][c - 1];
		}
		cout << endl;
	}
	cout << endl;
}