#include "Map.h"

Map::Map()
{
	// Number of interesting nodes should be 0, initialize the head pointer
	numberofnodes = 0;
	head = new MapData;

	// head is a dummy variable, head->next is the "head" and "tail" at this point
	head->next = nullptr;
}

Map::~Map()
{
	// Start with the head, use this as a tracker
	MapData* temp = head;
	for (MapData* p = head; p != nullptr; p = temp)
	{
		// Keep track
		temp = p->next;

		// Delete if not null pointer
		delete p;
	}
}

Map::Map(const Map& other)
{
	// Initialize member variables, head first

	head = new MapData;
	head->next = nullptr;

	// Insert respective key and values
	for (MapData* p = other.head->next; p != nullptr; p = p->next)
	{
		this->insert(p->key, p->value);
	}

	// Precaution to ensure nodes are the same
	numberofnodes = other.numberofnodes;
}

Map& Map::operator = (const Map& rhs)
{
	// Make sure that copy operator does not refer to itself, would be redundant
	if (this != &rhs)
	{
		Map temp(rhs);
		swap(temp);
	}

	// temp is deleted along with old data from left hand side

	return *this;
}

bool Map::empty() const
{
	// Only true if number of interesting nodes is 0
	return (numberofnodes == 0);
}

int Map::size() const
{
	// Return number of interesting nodes
	return (numberofnodes);
}

bool Map::insert(const KeyType& key, const ValueType& value)
{
	// Iterate through to find the "tail", or a key identical to parameter key of the linked list
	MapData* p = head;
	for (; (p->next != nullptr) && (p->next->key != key); p = p->next);

	// Return false if the next key is already in the list
	if ((p->next != nullptr) && (p->next->key == key))
		return false;
	
	// Initialize the new node's data members with function parameters, set pointers to next items in list and preceding ones
	p->next = new MapData;
	p->next->key = key;
	p->next->value = value;
	p->next->next = nullptr; 
	p->next->prev = p; // Sort by going through p->next to ensure that p->prev can be recorded
	numberofnodes++;

	return true;
}

bool Map::update(const KeyType& key, const ValueType& value)
{
	// Iterate through to find the "tail", or matching key to change the value

	MapData* p = head->next;
	for (; (p != nullptr) && (p->key != key); p = p->next);

	if ((p != nullptr) && (p->key == key))
	{
		p->value = value;
		return true;
	}

	return false;
}

bool Map::insertOrUpdate(const KeyType& key, const ValueType& value)
{
	// Cannot be false, insert will only not work if key is in list, but then update will work
	return ((insert(key, value)) || (update(key, value)));
}

bool Map::erase(const KeyType& key)
{
	MapData* p = head->next;
	for (; (p != nullptr) && (p->key != key); p = p->next);

	if ((p != nullptr) && (p->key == key))
	{
		// If item is the last of its list
		if (p->next == nullptr)
		{
			p->prev->next = nullptr;
			delete p;
		}

		// Set the previous node's next to this node's next and next node's previous to this node's previous
		else
		{
			p->prev->next = p->next;
			p->next->prev = p->prev;
			delete p;
		}
		numberofnodes--;
		return true;
	}
	
	return false;
}

bool Map::contains(const KeyType& key) const
{
	MapData* p = head->next;
	for (; (p != nullptr) && (p->key != key); p = p->next);

	// True if key was found, in which the pointer to MapData would not be nullptr
	return (p != nullptr);
}

bool Map::get(const KeyType& key, ValueType& value) const
{
	MapData* p = head->next;
	for (; (p != nullptr) && (p->key != key); p = p->next);
	
	if ((p != nullptr) && (p->key == key))
	{
		// Find the respective key and insert that value into parameter value
		value = p->value;
		return true;
	}

	return false;
}
bool Map::get(int i, KeyType& key, ValueType& value) const
{
	if ((i >= 0) && (i < numberofnodes))
	{
		// Possibly iterates from 0 to numberofnodes - 1
		MapData* p = head;
		for (int j = 0; j <= i; j++)
		{
			p = p->next;
		}

		// Record the values in parameter keys and values
		key = p->key;
		value = p->value;
		return true;
	}

	return false;

}

void Map::swap(Map& other)
{
	// Simply swap the heads to swap linked lists
	MapData* temp = other.head;
	other.head = head;
	head = temp;

	// Change the numberofnodes as well
	int temp2 = other.numberofnodes;
	other.numberofnodes = numberofnodes;
	numberofnodes = temp2;
}

bool combine(const Map& m1, const Map& m2, Map& result)
{
	int i = 0;
	KeyType k;
	ValueType v;
	bool returntype = false; // Assume that there are no duplicates in m1 and m2

	Map m;
	
	// Insert all values of m1 into the Map object created
	while (m1.get(i, k, v))
	{
		m.insert(k, v);
		i++;
	}

	i = 0;

	while (m2.get(i, k, v))
	{
		// If m.insert is false, that means that a key with the same value is in there

		if (m.insert(k, v) == false)
		{
			ValueType temp = v;
			m.get(k, v);

			if (temp != v)
				m.erase(k); // Erase the key from the map created if the values aren't the same, as it doesn't meet the requirements of combine
			else
				returntype = true;
		}
		i++;
	}

	result = m; // Swap result with map created
	return returntype;
}

void reassign(const Map& m, Map& result)
{
	int i = 1; // Start at the second item of the m list, if possible
	KeyType k;
	ValueType v;

	Map dupe;
	// Start inserting m list values one item ahead
	while (m.get(i, k, v))
	{
		dupe.insert(k, v);
		i++;
	}
	// First item inserted last
	if (m.get(0, k, v))
	{
		dupe.insert(k, v);
	}

	// Now swap the ValueTypes, they are in different orders, so swapping ValueTypes creates different value pairs
	for (i = 0; i < m.size(); i++)
	{
		m.get(i, k, v);
		ValueType temp = v;

		dupe.get(i, k, v);
		dupe.update(k, temp);
	}

	result = dupe; // Swap result with dupe created

}
