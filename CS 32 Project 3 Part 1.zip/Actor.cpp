#include "Actor.h"
#include "StudentWorld.h"
#include "GraphObject.h"
#include "GameConstants.h"
#include <cmath>

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp

const double Pi = 2 * asin(1);

double convertToRadian(int angle)
{
	return angle* Pi / 180;
}
																			// ACTOR
Actor::Actor(StudentWorld* world, int imageID, int startX, int startY, Direction startDirection, int depth, int hp)
	: GraphObject(imageID, startX, startY, startDirection, depth), this_world(world), isAlive(true), hitpoints(hp)
{

}

StudentWorld* Actor::getAPointerToMyStudentWorld()
{
	return this_world;
}

void Actor::doSomething()
{

}
																			// SOCRATES

Socrates::Socrates(StudentWorld* world)
	: Actor(world, 0, 0, 128, 0, 0, 100), positional_angle(180)
{

}

void Socrates::PlayerMove(int angle_change)
{
	positional_angle += angle_change;

	moveTo(VIEW_WIDTH / 2 + (VIEW_RADIUS) * cos(convertToRadian(positional_angle)),
		VIEW_HEIGHT / 2 + (VIEW_RADIUS) * sin(convertToRadian(positional_angle)));

	setDirection(positional_angle + 180);

}

void Socrates::doSomething()
{
	int ch;
	if (getAPointerToMyStudentWorld()->getKey(ch))
	{
		// user hit a key during this tick!
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			PlayerMove(5);
			break;
		case KEY_PRESS_RIGHT:
			PlayerMove(-5);
			break;
		}
	}
}

																			// DIRT

Dirt::Dirt(StudentWorld* world, int startX, int startY)
	: Actor(world, IID_DIRT, startX, startY, 0, 1, 0)
{

}

void Dirt::doSomething()
{

}