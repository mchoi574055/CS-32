#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class Actor : public GraphObject
{
	public:
		Actor(StudentWorld* world, int imageID, int startX, int startY, Direction startDirection, int depth, int hp);
		virtual void doSomething();
		StudentWorld* getAPointerToMyStudentWorld();

	private:
		StudentWorld* this_world;
		bool isAlive;
		int hitpoints;

};

class Socrates : public Actor
{
	public:
		Socrates(StudentWorld* world);
		void doSomething();
		void PlayerMove(int angle_change);
	
	private:
		int positional_angle;


};

class Dirt : public Actor
{
	public:
		Dirt(StudentWorld* world, int startX, int startY);
		void doSomething();
	
	private:
};

#endif // ACTOR_H_

