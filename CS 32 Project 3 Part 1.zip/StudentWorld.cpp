#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
}

int StudentWorld::init()
{
	// Socrates
	socrates = new Socrates(this);

	// Dirt , STILL NEED TO MAKE SURE NO OVERLAP WITH FOOD OBJECTS OR PITS
	int L = getLevel();
	int limit = max(180 - 20 * L, 20);
	
	for (int i = 0; i < limit; i++)
	{
		int width = randInt((VIEW_WIDTH / 2) - 120, (VIEW_WIDTH / 2) + 120);
		int height = randInt((VIEW_HEIGHT / 2) - 120, (VIEW_HEIGHT / 2) + 120);

		while (sqrt((width - VIEW_WIDTH / 2) * (width - VIEW_WIDTH / 2) + (height - VIEW_WIDTH / 2) * (height - VIEW_WIDTH / 2)) > 120)
		{
			width = randInt((VIEW_WIDTH / 2) - 120, (VIEW_WIDTH / 2) + 120);
			height = randInt((VIEW_HEIGHT / 2) - 120, (VIEW_HEIGHT / 2) + 120);
		}

		actors.push_back(new Dirt(this, width, height));
	}


    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	socrates->doSomething();

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	delete socrates;

	for (vector<Actor*>::iterator p = actors.begin(); p != actors.end();)
	{
		delete *p;
		p = actors.erase(p);
	}
}

StudentWorld::~StudentWorld()
{
	cleanUp();
}
