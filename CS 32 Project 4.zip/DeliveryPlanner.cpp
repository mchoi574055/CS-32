#include <stdio.h>
#include <sstream>
#include <fstream>
#include "provided.h"
#include <vector>
#include <list>

using namespace std;

class DeliveryPlannerImpl
{
public:
    DeliveryPlannerImpl(const StreetMap* sm);
    ~DeliveryPlannerImpl();
    DeliveryResult generateDeliveryPlan(
        const GeoCoord& depot,
        const vector<DeliveryRequest>& deliveries,
        vector<DeliveryCommand>& commands,
        double& totalDistanceTravelled) const;
private:
	string getTurndirectionection(double angle) const {
		string direction;
		if (angle < 22.5 && angle >= 0) {
			direction = "east";
		}
		else if (angle < 67.5) {
			direction = "northeast";
		}
		else if (angle < 112.5) {
			direction = "north";
		}
		else if (angle < 157.5) {
			direction = "northwest";
		}
		else if (angle < 202.5) {
			direction = "west";
		}
		else if (angle < 247.5) {
			direction = "southwest";
		}
		else if (angle < 292.5) {
			direction = "south";
		}
		else if (angle < 337.5) {
			direction = "southeast";
		}
		else {
			direction = "east";
		}
		return direction;
	}
    const StreetMap* streetname;
};

DeliveryPlannerImpl::DeliveryPlannerImpl(const StreetMap* sm)
{
    streetname = sm;
}

DeliveryPlannerImpl::~DeliveryPlannerImpl()
{
}

DeliveryResult DeliveryPlannerImpl::generateDeliveryPlan(
    const GeoCoord& depot,
    const vector<DeliveryRequest>& deliveries,
    vector<DeliveryCommand>& commands,
    double& totalDistanceTravelled) const
{
    vector<DeliveryRequest> newOrder = deliveries;
    DeliveryOptimizer d_optimizer(streetname);
    double distancePrev;
    double distanceNew;
    d_optimizer.optimizeDeliveryOrder(depot, newOrder, distancePrev, distanceNew);
    
    // Keep track of Homebase to go home
    totalDistanceTravelled = 0;
    GeoCoord HOMEBASE = depot;
    for(int i=0; i<newOrder.size(); i++){
        PointToPointRouter p(streetname);
        list<StreetSegment> routes;
        double d;
        if(HOMEBASE == newOrder[i].location){
            DeliveryCommand DELIVERCOMMAND; // Deliver command
            DELIVERCOMMAND.initAsDeliverCommand(newOrder[i].item);
            commands.push_back(DELIVERCOMMAND);
            continue;
        }
        DeliveryResult status_code = p.generatePointToPointRoute(HOMEBASE, newOrder[i].location, routes, d);
        if(status_code!=DELIVERY_SUCCESS){
            return status_code;
        }
        list<StreetSegment>::iterator it = routes.begin();
        StreetSegment EndStreet = (*it);
        double streetDist = 0;
        while(it!=routes.end()){
            StreetSegment StreetOfInterest = (*it);
            
            if(StreetOfInterest == routes.back()){
                //generate angle proceed command and DELIVERCOMMAND command;
                DeliveryCommand proceed;
                double angle = angleOfLine(EndStreet);
                string direction = getTurndirectionection(angle);
                streetDist += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
                totalDistanceTravelled += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
                proceed.initAsProceedCommand(direction, StreetOfInterest.name, streetDist);
                DeliveryCommand DELIVERCOMMAND;
                DELIVERCOMMAND.initAsDeliverCommand(newOrder[i].item);
                commands.push_back(proceed);
                commands.push_back(DELIVERCOMMAND);
                break;
            }
            if(StreetOfInterest.name!=EndStreet.name){
                //generate delivery command
                DeliveryCommand command;
                double angle = angleOfLine(EndStreet);
                string direction = getTurndirectionection(angle);
                command.initAsProceedCommand(direction, EndStreet.name, streetDist);
                commands.push_back(command);
                DeliveryCommand turn;
                angle = angleBetween2Lines(EndStreet, StreetOfInterest);
                if(angle<1 || angle>359){
                    //proceed onto the street
                    EndStreet = StreetOfInterest;
                    streetDist = 0;
                    continue;
                }else if(angle>=1 && angle<180){
                    //generate left turn:
                    turn.initAsTurnCommand("left", StreetOfInterest.name);
                    commands.push_back(turn);
                }else if(angle>=180 && angle<359){
                    //generate right turn
                    turn.initAsTurnCommand("right", StreetOfInterest.name);
                    commands.push_back(turn);
                }
                
                EndStreet = StreetOfInterest;
                streetDist = 0;
            }
            
            streetDist += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
            totalDistanceTravelled += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
            it++;
        }
        HOMEBASE = newOrder[i].location;
    }
    
	// Head home
    
    PointToPointRouter p(streetname);
    list<StreetSegment> routes;
    double d;
    p.generatePointToPointRoute(newOrder[newOrder.size()-1].location, depot, routes, d);
    list<StreetSegment>::iterator it = routes.begin();
    StreetSegment EndStreet = (*it);
    double streetDist = 0;
    while(it!=routes.end()){
        
        StreetSegment StreetOfInterest = (*it);
        
        if(StreetOfInterest == routes.back()){
           // Find the next angle to proceed
            DeliveryCommand proceed;
            double angle = angleOfLine(EndStreet);
            string direction = getTurndirectionection(angle);
            streetDist += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
            totalDistanceTravelled += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
            proceed.initAsProceedCommand(direction, StreetOfInterest.name, streetDist);
            commands.push_back(proceed);
            break;
        }
        if(StreetOfInterest.name!=EndStreet.name){
           /// Proceed into the fray
            DeliveryCommand command;
            double angle = angleOfLine(EndStreet);
            string direction = getTurndirectionection(angle);
            command.initAsProceedCommand(direction, EndStreet.name, streetDist);
            commands.push_back(command);
            DeliveryCommand turn;
            angle = angleBetween2Lines(EndStreet, StreetOfInterest);
            if(angle<1 || angle>359){
            // Keep going in on the streeet
                EndStreet = StreetOfInterest;
                streetDist = 0;
                continue;
				// Compute angle to rotate
            }else if(angle>=1 && angle<180){
				// Compute left turn
                turn.initAsTurnCommand("left", StreetOfInterest.name);
                commands.push_back(turn);
            }else if(angle>=180 && angle<359){
                // Compute right turn
                turn.initAsTurnCommand("right", StreetOfInterest.name);
                commands.push_back(turn);
            }
            
            EndStreet = StreetOfInterest;
            streetDist = 0;
        }
        
        streetDist += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
        totalDistanceTravelled += distanceEarthMiles(StreetOfInterest.start, StreetOfInterest.end);
        it++;
    }
    
    
    return DELIVERY_SUCCESS;
}



//******************** DeliveryPlanner functions ******************************

// These functions simply delegate to DeliveryPlannerImpl's functions.
// You probably don't want to change any of this code.

DeliveryPlanner::DeliveryPlanner(const StreetMap* sm)
{
    m_impl = new DeliveryPlannerImpl(sm);
}

DeliveryPlanner::~DeliveryPlanner()
{
    delete m_impl;
}

DeliveryResult DeliveryPlanner::generateDeliveryPlan(
    const GeoCoord& depot,
    const vector<DeliveryRequest>& deliveries,
    vector<DeliveryCommand>& commands,
    double& totalDistanceTravelled) const
{
    return m_impl->generateDeliveryPlan(depot, deliveries, commands, totalDistanceTravelled);
}