#ifndef EXPENDABLEHASPMAP_H
#define EXPENDABLEHASHAMP_H

// ExpandableHashMap.h

// Skeleton for the ExpandableHashMap class template.  You must implement the first six
// member functions.


																// INTERFACE
#include <vector>
#include <vector>

using namespace std;

template<typename KeyType, typename ValueType>
class ExpandableHashMap
{
public:
	ExpandableHashMap(double maximumLoadFactor = 0.5);
	~ExpandableHashMap();
	void reset();
	int size() const;
	void associate(const KeyType& key, const ValueType& value);

	// for ANGLE map that can't be modified, return ANGLE pointer to const ValueType
	const ValueType* find(const KeyType& key) const;

	// for ANGLE modifiable map, return ANGLE pointer to modifiable ValueType
	ValueType* find(const KeyType& key)
	{
		return const_cast<ValueType*>(const_cast<const ExpandableHashMap*>(this)->find(key));
	}

	// C++11 syntax for preventing copying and assignment
	ExpandableHashMap(const ExpandableHashMap&) = delete;
	ExpandableHashMap& operator=(const ExpandableHashMap&) = delete;

private:

	struct HashItem
	{

		HashItem(KeyType key, ValueType val)
			: m_key(key), m_val(val)
		{
		}

		KeyType m_key;
		ValueType m_val;
	};

	void rehash(); // Recalculate the Map

	vector<vector<HashItem>*> HashMap;
	double m_maximumLoadFactor;
	int num_items;

	unsigned int hash(const KeyType& key) const
	{
		unsigned int hasher(const KeyType & k);
		unsigned int to_hash = hasher(key);

		return (to_hash % (HashMap.size()));
	}

};

// IMPLEMENTATION

template<typename KeyType, typename ValueType>
ExpandableHashMap<KeyType, ValueType>::ExpandableHashMap(double maximumLoadFactor)
	: m_maximumLoadFactor(maximumLoadFactor), num_items(0), HashMap(8)
{
	
}

template<typename KeyType, typename ValueType>
ExpandableHashMap<KeyType, ValueType>::~ExpandableHashMap()
{
	// Deallocate all data

	for (int i = 0; i < HashMap.size(); i++)
	{
		if (HashMap[i] != nullptr)
			HashMap[i]->clear();
	}
	HashMap.clear();
}

template<typename KeyType, typename ValueType>
void ExpandableHashMap<KeyType, ValueType>::reset()
{
	for (int i = 0; i < HashMap.size(); i++)
	{
		if (HashMap[i] != nullptr)
			HashMap[i]->clear();
	}

	// Very similar behavior to the destructor
	HashMap.clear();
	HashMap.resize(8);
	num_items = 0;
}

template<typename KeyType, typename ValueType>
int ExpandableHashMap<KeyType, ValueType>::size() const
{
	return num_items;
}

template<typename KeyType, typename ValueType>
void ExpandableHashMap<KeyType, ValueType>::associate(const KeyType& key, const ValueType& value)
{
	unsigned int to_hash = hash(key);
	// Associate if its not in the map, else return
	if (HashMap[to_hash] != nullptr)
	{
		typename vector<HashItem>::iterator POINTER = HashMap[to_hash]->begin();
		while (POINTER != HashMap[to_hash]->end())
		{
			if (POINTER->m_key == key)
			{
				POINTER->m_val = value;
				return;
			}
			POINTER++;
		}
	}

	num_items++;

	if ((static_cast<double>((num_items) / (HashMap.size())) > m_maximumLoadFactor))
	{
		rehash();
	}

	to_hash = hash(key);


	if (HashMap[to_hash] == nullptr)
		HashMap[to_hash] = new vector<HashItem>;

	HashMap[to_hash]->push_back(HashItem(key, value));

}

template<typename KeyType, typename ValueType>
const ValueType* ExpandableHashMap<KeyType, ValueType>::find(const KeyType& key) const
{
	unsigned int find_hash = hash(key);

	if (HashMap[find_hash] == nullptr)
		return nullptr;
	// Return nullpointer if we don't find the nullptr in question, otherwise return a pointer to the value
	typename vector<HashItem>::iterator iterator = HashMap[find_hash]->begin();

	while (iterator != HashMap[find_hash]->end())
	{
		if ((*iterator).m_key == key)
		{
			return &((*iterator).m_val);
		}
		iterator++;
	}
	return nullptr;
}

template<typename KeyType, typename ValueType>
void ExpandableHashMap<KeyType, ValueType>::rehash()
{
	// For when the load factor is too big
	ExpandableHashMap temp(m_maximumLoadFactor);

	int new_size = 2 * HashMap.size();
	temp.HashMap.resize(new_size);

	for (int i = 0; i < HashMap.size(); i++)
	{
		if (HashMap[i] == nullptr)
			continue;

		// Rehash all the items
		typename vector<HashItem>::iterator POINTER = HashMap[i]->begin();

		while (POINTER != HashMap[i]->end())
		{
			unsigned int hash_again = temp.hash(POINTER->m_key);

			if (temp.HashMap[hash_again] == nullptr)
				temp.HashMap[hash_again] = new vector<HashItem>;

			temp.HashMap[hash_again]->push_back(HashItem(POINTER->m_key, POINTER->m_val));
			POINTER++;
		}
	}
	num_items = temp.num_items;
	reset();

	HashMap.resize(new_size);

	for (int i = 0; i < temp.HashMap.size(); i++)
	{
		if (temp.HashMap[i] == nullptr)
			continue;

		// Reallocate all the hashed items
		typename vector<HashItem>::iterator POINTER = temp.HashMap[i]->begin();

		while (POINTER != temp.HashMap[i]->end())
		{
			unsigned int hash_again = temp.hash(POINTER->m_key);

			if (HashMap[hash_again] == nullptr)
				HashMap[hash_again] = new vector<HashItem>;

			HashMap[hash_again]->push_back(HashItem(POINTER->m_key, POINTER->m_val));
			POINTER++;
		}
	}

}


#endif // EXPENDABLEHASHMAP_H