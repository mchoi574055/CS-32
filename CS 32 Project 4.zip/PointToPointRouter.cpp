#include <stdio.h>
#include "provided.h"
#include <vector>
#include <queue>
#include "ExpandableHashMap.h"
#include <stack>
#include <map>
#include <list>

using namespace std;

class PointToPointRouterImpl
{
public:
	PointToPointRouterImpl(const StreetMap* sm);
	~PointToPointRouterImpl();
	DeliveryResult generatePointToPointRoute(
		const GeoCoord& start,
		const GeoCoord& end,
		list<StreetSegment>& route,
		double& totalDistanceTravelled) const;
private:
	const StreetMap* streetmap;
};

struct ToHash {
	// Implement this so that we can have a priority queue
	ToHash(const GeoCoord& geocoord, const double distance) :
		key(geocoord), val(distance)
	{}
	// Hash these items
	GeoCoord key;
	double val;
};

// This is the hasher definition for priority queue to ensure that the appropriate sortiing happens
bool operator<(const ToHash& p1, const ToHash& p2) {
	return (p1.val < p2.val);
}

PointToPointRouterImpl::PointToPointRouterImpl(const StreetMap* sm)
{
	streetmap = sm;
}

PointToPointRouterImpl::~PointToPointRouterImpl()
{
}

DeliveryResult PointToPointRouterImpl::generatePointToPointRoute(
	const GeoCoord& start,
	const GeoCoord& end,
	list<StreetSegment>& route,
	double& totalDistanceTravelled) const
{

	// Implement these two maps to track distance and the route taken
	priority_queue<ToHash> prio_queue;
	map<GeoCoord, double> trackDistance;
	map<GeoCoord, GeoCoord> trackRoute;

	if (start == end) 
	{
		totalDistanceTravelled = 0;
		route.clear();
		return DELIVERY_SUCCESS;
	}

	vector<StreetSegment> temp;
	if (!(streetmap->getSegmentsThatStartWith(start, temp) || !(streetmap->getSegmentsThatStartWith(end, temp))))
	{
		return BAD_COORD;
	}

	// push the queue forward
	prio_queue.push(ToHash(start, 0));

	trackDistance.insert_or_assign(start, 0);
	trackRoute.insert_or_assign(start, start);

	
	// Implement this to track the progress of the queue
	GeoCoord tracker;


	while (!prio_queue.empty()) 
	{
		string read;
		tracker = prio_queue.top().key;
		prio_queue.pop();

		if (tracker == end) {
			break;
	}

		vector<StreetSegment> temp;
		streetmap->getSegmentsThatStartWith(tracker, temp);

		for (int i = 0; i < temp.size(); i++)
		{
			map<GeoCoord, double>::iterator iterator = trackDistance.find(tracker);
			double new_cost = (iterator->second) + distanceEarthMiles(tracker, temp[i].end);

			iterator = trackDistance.find(temp[i].end);

			if (iterator == trackDistance.end() || new_cost < (iterator->second)) {
				trackDistance.insert_or_assign(temp[i].end, new_cost);

				double priority = -(new_cost + distanceEarthMiles(temp[i].end, end));
				prio_queue.push(ToHash(temp[i].end, priority));
				trackRoute.insert_or_assign(temp[i].end, tracker);
			}

		}

	}

	if (tracker != end) 
	{
		return NO_ROUTE;
	}

	route.clear();

	// Clear the route, get ready to input items

	GeoCoord EndPoint = end;
	stack<StreetSegment> computeRoute;


	// Make sure we are not at the beginning
	while (EndPoint != start) 
	{
		GeoCoord CompletePath = EndPoint;
		map<GeoCoord, GeoCoord>::iterator iterator = trackRoute.find(EndPoint);
		EndPoint = iterator->second;
		string name;

		vector<StreetSegment> temp;
		streetmap->getSegmentsThatStartWith(EndPoint, temp);
		for (int i = 0; i < temp.size(); i++) {
			if (temp[i].end == CompletePath) {
				name = temp[i].name;
			}
		}
		StreetSegment s(EndPoint, CompletePath, name);
		computeRoute.push(s);
	}

	// Pop the stack with the streetSegments into the computeRoute
	while (!computeRoute.empty()) 
	{
		route.push_back(computeRoute.top());
		computeRoute.pop();
	}

	map<GeoCoord, double>::iterator iterator = (trackDistance.find(end));
	totalDistanceTravelled = iterator->second;

	// Delivery was a success
	return DELIVERY_SUCCESS;
}

//******************** PointToPointRouter functions ***************************

// These functions simply delegate to PointToPointRouterImpl's functions.
// You probably don't want to change any of this code.

PointToPointRouter::PointToPointRouter(const StreetMap* sm)
{
	m_impl = new PointToPointRouterImpl(sm);
}

PointToPointRouter::~PointToPointRouter()
{
	delete m_impl;
}

DeliveryResult PointToPointRouter::generatePointToPointRoute(
	const GeoCoord& start,
	const GeoCoord& end,
	list<StreetSegment>& route,
	double& totalDistanceTravelled) const
{
	return m_impl->generatePointToPointRoute(start, end, route, totalDistanceTravelled);
}