#include "provided.h"
#include <string>
#include <vector>
#include <functional>
#include <fstream>
#include <istream>

// HASHMAP
#include "ExpandableHashMap.h"

using namespace std;

unsigned int hasher(const GeoCoord& g)
{
	return std::hash<string>()(g.latitudeText + g.longitudeText);
}

class StreetMapImpl
{
public:
	StreetMapImpl();
	~StreetMapImpl();
	bool load(string mapFile);
	bool getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const;


private:
	ExpandableHashMap<GeoCoord, vector<StreetSegment>> HashMap;
};


StreetMapImpl::StreetMapImpl()
{

}

StreetMapImpl::~StreetMapImpl()
{

}

bool StreetMapImpl::load(string mapFile)
{

	ifstream infile(mapFile);
	if (!infile)
	{
		return false;
	}

	string line_to_read;
	while (getline(infile, line_to_read))
	{
		string LineToRead;
		getline(infile, LineToRead);
		int numberOfStreetSegments = stoi(LineToRead);
		for (int i = 0; i < numberOfStreetSegments; i++)
		{
			string StreetSegmentInQuestion;

			//Gather each line in question
			getline(infile, StreetSegmentInQuestion); 
			string StreetSegmentBeginning = StreetSegmentInQuestion.substr(0, StreetSegmentInQuestion.find(" "));

			// Ignore the empty spaces

			StreetSegmentInQuestion = StreetSegmentInQuestion.substr(StreetSegmentInQuestion.find(" ") + 1, StreetSegmentInQuestion.size() - 1);

			string StreetSegmentOtherBeginning = StreetSegmentInQuestion.substr(0, StreetSegmentInQuestion.find(" "));

			GeoCoord CoordinateOne(StreetSegmentBeginning, StreetSegmentOtherBeginning); 

			StreetSegmentInQuestion = StreetSegmentInQuestion.substr(StreetSegmentInQuestion.find(" ") + 1, StreetSegmentInQuestion.size() - 1);

			// Repeat

			string EndSegment = StreetSegmentInQuestion.substr(0, StreetSegmentInQuestion.find(" "));

			StreetSegmentInQuestion = StreetSegmentInQuestion.substr(StreetSegmentInQuestion.find(" ") + 1, StreetSegmentInQuestion.size() - 1);

			string StreetSegmentEndingOtherSegment = StreetSegmentInQuestion.substr(0, StreetSegmentInQuestion.find(" "));

			GeoCoord CoordinateTwo(EndSegment, StreetSegmentEndingOtherSegment);

			StreetSegment StreetSegmentForward(CoordinateOne, CoordinateTwo, line_to_read); 

			StreetSegment StreetSegmentReverse(CoordinateTwo, CoordinateOne, line_to_read);

			// Input into the HashMap

			if (HashMap.find(CoordinateOne) == nullptr) 
			{
				vector<StreetSegment> temp;
				temp.push_back(StreetSegmentForward);
				HashMap.associate(CoordinateOne, temp);
		
			}
			else
			{
				vector<StreetSegment>* point = HashMap.find(CoordinateOne);
				point->push_back(StreetSegmentForward);
			}
			if (HashMap.find(CoordinateTwo) == nullptr)
			{
				vector<StreetSegment> temp;
				temp.push_back(StreetSegmentReverse);
				HashMap.associate(CoordinateTwo, temp);

			}
			else
			{
				vector<StreetSegment>* point = HashMap.find(CoordinateTwo);
				point->push_back(StreetSegmentReverse);
			}
		}
	}
	return true;
}

bool StreetMapImpl::getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const
{
	const vector<StreetSegment>* findVals = HashMap.find(gc);

	if (findVals == nullptr)
		return false;

	segs = *(HashMap.find(gc));

	return true;
}

//******************** StreetMap functions ************************************

// These functions simply delegate to StreetMapImpl's functions.
// You probably don't want to change any of this code.

StreetMap::StreetMap()
{
	m_impl = new StreetMapImpl;
}

StreetMap::~StreetMap()
{
	delete m_impl;
}

bool StreetMap::load(string mapFile)
{
	return m_impl->load(mapFile);
}

bool StreetMap::getSegmentsThatStartWith(const GeoCoord& gc, vector<StreetSegment>& segs) const
{
	return m_impl->getSegmentsThatStartWith(gc, segs);
}
